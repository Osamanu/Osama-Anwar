import sys
import os
from pathlib import Path
import pandas as pd
import xml.etree.ElementTree as ET

#Provide the Folder path where XML files are located
folder_path=" ".join(sys.argv[1:])


#Reading the xml files
def get_files(d):
        return [os.path.join(d, f) for f in os.listdir(d) if os.path.isfile(os.path.join(d,f))]

def sqlquery(myroot,filename):
    '''
    Extracting the sql queries
    '''
    SQlquery=[]
    for item in myroot.findall('.//_.fcp.ObjectModelEncapsulateLegacy.true...object-graph//objects//object//properties//relation'):
        if item.attrib['type']=='text':
            connection=item.attrib['connection'].split(".")[0]
            name =item.attrib['name']
            
            SQlquery.append([filename,'Custom SQL',connection,name,item.text])
            
    for item in myroot.findall('.//_.fcp.ObjectModelEncapsulateLegacy.false...relation'):
        if item.attrib['type']=='text':
            connection=item.attrib['connection'].split(".")[0]
            name =item.attrib['name']
            SQlquery.append([filename,'Custom SQL',connection,name,item.text])
        
    #convert the list of sql query into a data frame
    if len(SQlquery)>0:
        sqldata = SQlquery
        sqldata = pd.DataFrame(sqldata, columns=['Workbook Name','Category','Connection','Query Name','Query'])

        return sqldata


def formula(myroot,filename):
    '''
    Extracting formula and its name
    '''
    print('formula')
    calcDict = {}
    for item in myroot.findall('.//column[@caption]'):
        if item.find(".//calculation") is None:
            continue
        else:
            calcDict[item.attrib['name']] = '[' + item.attrib['caption'] + ']'

            
            
            
    calcList = []
    for item in myroot.findall('.//column[@caption]'):
        if item.find(".//calculation") is None:
            continue
        else:
            if item.find(".//calculation[@formula]") is None:
                continue
            else:

                calc_name = item.attrib['caption']
                calc_raw_formula = item.find(".//calculation").attrib['formula']

                calc_formula = ''
                for line in calc_raw_formula.split('\r\n'):
                    calc_formula = calc_formula + line + ' '
                    for name, caption in calcDict.items():
                        calc_formula = calc_formula.replace(name, caption)
                        calc_row = (filename,'Calculated Field',calc_name, calc_formula) 
        calcList.append(list(calc_row))
    #convert the list of formula into a data frame
    data = calcList
    data = pd.DataFrame(data, columns=['Workbook Name','Category','Name', 'Formula'])
    
    return data
        
def oneSql(myroot,filename):
    '''
    Extracting the one time sql and source name if present
    '''
    initial_Sql=[]

    for item in myroot.findall('.//datasource'):

        if item.find('.//connection//named-connections//named-connection//connection[@one-time-sql]') is None:
            
            continue
        else:

            if len(item.find('.//connection//named-connections//named-connection//connection').attrib['one-time-sql'])!=0:
                
                if item.find('[@caption]') is None:
                    source=item.attrib['name']
                    print(source)
                else:

                    source=item.attrib['caption']
                    #print(source)

                sql=item.find('.//connection//named-connections//named-connection//connection').attrib['one-time-sql']
                

                initial_Sql.append([filename,'Initial SQL',source,sql])
        if item.find('.//repository-location//connection//named-connections//named-connection//connection[@one-time-sql]') is None:
            
            continue

        else:
            if len(item.find('.//repository-location//connection//named-connections//named-connection//connection').attrib['one-time-sql'])!=0:
                if item.find('[@caption]') is None:
                    source=item.attrib['name']
                    #print(source)
                else:
                    source=item.attrib['caption']
                sql=item.find('.//repository-location//connection//named-connections//named-connection//connection').attrib['one-time-sql']
                

                initial_Sql.append([filename,'Initial SQL',source,sql])

    

    if len(initial_Sql)!=0:
        

        
        df=pd.DataFrame(initial_Sql,columns=['Workbook Name','Category','Source Name','On-time-SQl'])
        df.drop_duplicates(inplace=True)
 
        return df

def parse(files):
    frames=[]
    for i in files:
        file=Path(i).name
        filename=file.split('.')[0]
       
        print('**********',filename,'*********')
        mytree = ET.parse(i)
        myroot = mytree.getroot()
        
        s1=sqlquery(myroot,filename)
        frames.append(s1)
        
        s2=oneSql(myroot,filename)
        frames.append(s2)
        
        s3=formula(myroot,filename)
        frames.append(s3)

    result=pd.concat(frames)
    return result   






files=get_files(folder_path)
final_df=parse(files)
final_df.to_csv('workbook_extraction.csv',index=False)